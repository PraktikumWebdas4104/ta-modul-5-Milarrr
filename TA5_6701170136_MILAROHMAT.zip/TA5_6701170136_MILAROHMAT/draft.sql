-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 07. Oktober 2018 jam 10:52
-- Versi Server: 5.5.16
-- Versi PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `draft`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `NIM` int(10) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`NIM`, `Nama`, `Email`) VALUES
(0, '1234', 'titawidya@gmail.com'),
(2147483647, 'mila', 'milaarr@gmail.com'),
(2147483647, 'mila', 'milaarr@gmail.com'),
(2147483647, '', ''),
(1234567891, 'Miila Rohmat', 'mila@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `masuk`
--

CREATE TABLE IF NOT EXISTS `masuk` (
  `email` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `registrasi`
--

CREATE TABLE IF NOT EXISTS `registrasi` (
  `jenis_kelamin` varchar(35) NOT NULL,
  `program` varchar(35) NOT NULL,
  `fakultas` varchar(35) NOT NULL,
  `hobi` varchar(35) NOT NULL,
  `upload` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `registrasi`
--

INSERT INTO `registrasi` (`jenis_kelamin`, `program`, `fakultas`, `hobi`, `upload`) VALUES
('', '', '', '', ''),
('Perempuan', 'saab', 'saab', 'baca', ''),
('Laki-laki', 'volvo', 'volvo', 'nulis', ''),
('Laki-laki', 'Manajemen Informatika', 'Ilmu Terapan', 'baca', ''),
('', 'Manajemen Informatika', 'Ilmu Terapan', 'main', ''),
('Laki-laki', 'Manajemen Informatika', 'Ilmu Terapan', 'main', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
