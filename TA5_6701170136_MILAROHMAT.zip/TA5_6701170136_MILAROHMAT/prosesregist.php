<?php
session_start();
include 'konregs.php';

$jenis_kelamin    = $_POST['jenis_kelamin'];
$program         = $_POST['program'];
$fakultas       = $_POST['fakultas'];
$hobi			 = $_POST['hobi'];
$upload        = $_POST['upload'];
 

?>
