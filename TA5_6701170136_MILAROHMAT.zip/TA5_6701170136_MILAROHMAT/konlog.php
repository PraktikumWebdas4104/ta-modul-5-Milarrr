<?php
$koneksi = new mysqli("localhost", "root", "", "draft");

  			if (isset($_POST['submit'])) {
				$koneksi = new mysqli("localhost", "root", "", "draft");

				if ($koneksi) {
					$email = $_POST['email'];
					$password = $_POST['password'];
					
					
					$sql = $koneksi->query("
						INSERT INTO `masuk` (`email`, `password`)
						VALUES ('$email', '$password')
										   ");
					echo "LOGIN SUKSES<br>";
				
			
					echo "LOGIN GAGAL";
				
				}else{
				}
  			}
 ?>