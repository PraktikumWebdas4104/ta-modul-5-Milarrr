<?php
session_start();
include "koneksi.php";


$nim = $_POST['Nim'];
$nama = $_POST['Nama'];
$email = $_POST['Email'];


Echo "data berhasil disimpan ";

?>