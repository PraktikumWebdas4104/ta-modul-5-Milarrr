<?php
session_start();
include "konlog.php";


$email = $_POST['email'];
$password = $_POST['password'];


Echo "data berhasil disimpan ";

?>
 <a href="data.html" > Lanjut ke registrasi </a>