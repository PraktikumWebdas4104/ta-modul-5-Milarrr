<?php
$koneksi = new mysqli("localhost", "root", "", "draft");

  			if (isset($_POST['submit'])) {
				$koneksi = new mysqli("localhost", "root", "", "draft");

				if ($koneksi) {
					$jenis_kelamin    = $_POST['jenis_kelamin'];
					$program         = $_POST['program'];
					$fakultas       = $_POST['fakultas'];
					$hobi			 = $_POST['hobi'];
					$upload        = $_POST['upload'];
					
					$sql = $koneksi->query("
						INSERT INTO `registrasi` (`jenis_kelamin`, `program`,`fakultas`,`hobi`,`upload`)
						VALUES ('$jenis_kelamin', '$program','$fakultas','$hobi','$upload')
										   ");
					echo "DATA SUKSES TERSIMPAN<br>";
				
			
					echo "DATA GAGAL DISIMPAN";
				
				}else{
				}
  			}
 ?>